package edu.sabanciuniv.cs310.happydorms;

import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.Arrays;

import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.facebook.widget.ProfilePictureView;

import edu.sabanciuniv.cs310.happydorms.services.*;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.Button;
import android.widget.TextView;

public class SelectionFragment extends Fragment{

	
	private ProfilePictureView profilePictureView;
	private TextView userNameView;
	private Button putadButton;
	private Button btnAllAds;
	public static String removeDiacriticalMarks(String string) {
	    return Normalizer.normalize(string, Form.NFD)
	        .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
	    
	}
	public static String turkishCharacters(String context)
	{
		  	context = context.replaceAll("İ","I");
		    context = context.replaceAll("ı","i");
		    context = context.replaceAll( "Ö","O");
		    context = context.replaceAll("ö","o");
		    context = context.replaceAll( "Ü","U");
		    context = context.replaceAll( "ü","u");
		    context = context.replaceAll("Ç","C");
		    context = context.replaceAll( "ç","c");
		    context = context.replaceAll( "Ğ","G");
		    context = context.replaceAll( "ğ","g;");
		    context = context.replaceAll( "Ş","S;");
		    context = context.replaceAll("ş","s;" );
		    return context;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, 
	        ViewGroup container, Bundle savedInstanceState) {
	    super.onCreateView(inflater, container, savedInstanceState);
	    View view = inflater.inflate(R.layout.profile_layout, 
	            container, false);
	 // Find the user's profile picture custom view
	   
	    profilePictureView = (ProfilePictureView) view.findViewById(R.id.selection_profile_pic);
	    profilePictureView.setCropped(true);
	    // Find the user's name view
	   putadButton=(Button)view.findViewById(R.id.postAd);
	   putadButton.setOnClickListener(new OnClickListener() {
		   
		   
		@Override
		public void onClick(View arg0) {
			
			if(putadButton.getText().toString().equals("Cancel Room Ad"))
			{
				putadButton.setText("Post Room Ad");
			}
			else
				putadButton.setText("Cancel Room Ad");
			
		}
		
	});
	   btnAllAds = (Button) view.findViewById(R.id.allAds);
	    if(btnAllAds == null){
	    	Log.i("DEVELOPER","btn is null");
	    }
	    btnAllAds.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i = new Intent(getActivity(), AddPoolActivity.class);
				//i.putExtra("reqid",reqid);
				startActivity(i);
				
				
			}
		});
	 // Find the user's profile picture custom view
	 // Check for an open session
	    Session session = Session.getActiveSession();
	    if (session != null && session.isOpened()) {
	        // Get the user's data
	        makeMeRequest(session);
	    }
	    return view;
	}
	private void makeMeRequest(final Session session) {
	    // Make an API call to get user data and define a 
	    // new callback to handle the response.
	    Request request = Request.newMeRequest(session, 
	            new Request.GraphUserCallback() {
			@Override
			public void onCompleted(GraphUser user, Response response) {
				 // If the response is successful
	            if (session == Session.getActiveSession()) {
	                if (user != null) {
	                    // Set the id for the ProfilePictureView
	                    // view that in turn displays the profile picture.
	                    profilePictureView.setProfileId(user.getId());
	                    // Set the Textview's text to the user's name
	                    String email=(String)(user.getProperty("email"));
	                    String name=String.valueOf(user.getFirstName());
	                    String lastname=String.valueOf(user.getLastName());
	                    String phone=null;
	                    String roominfo=null;
	                    name=removeDiacriticalMarks(name);
	                    lastname=removeDiacriticalMarks(lastname);
	                    name=turkishCharacters(name);
	                    
	                    Log.i("name",name);
	                    try {
	                    	
	                    	 RegisterWithFacebook regfb=new RegisterWithFacebook(name, lastname, email, roominfo, phone);
	 	                    regfb.execute();
							
						} catch (Exception e) {
							// TODO: handle exception
						}
	                   
	                }
	            }
	            if (response.getError() != null) {
	                // Handle errors, will do so later.
	            }
	        }

	    });
	    request.executeAsync();
	} 
	private void onSessionStateChange(final Session session, SessionState state, Exception exception) {
	    if (session != null && session.isOpened()) {
	        // Get the user's data.
	        makeMeRequest(session);
	      
	    }
	    else if(session != null && state.isClosed())
	    {
	    	Intent intent=new Intent(getActivity(),LoginActivity.class);
	    	startActivity(intent);
	    }
	}
	private UiLifecycleHelper uiHelper;
	private Session.StatusCallback callback = new Session.StatusCallback() {
	    @Override
	    public void call(final Session session, final SessionState state, final Exception exception) {
	        onSessionStateChange(session, state, exception);
	    }
	};
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    uiHelper = new UiLifecycleHelper(getActivity(), callback);
	    uiHelper.onCreate(savedInstanceState);
	}
	private static final int REAUTH_ACTIVITY_CODE = 100;
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
	    super.onActivityResult(requestCode, resultCode, data);
	    if (requestCode == REAUTH_ACTIVITY_CODE) {
	        uiHelper.onActivityResult(requestCode, resultCode, data);
	    }
	}
	@Override
	public void onResume() {
	    super.onResume();
	    uiHelper.onResume();
	}

	@Override
	public void onSaveInstanceState(Bundle bundle) {
	    super.onSaveInstanceState(bundle);
	    uiHelper.onSaveInstanceState(bundle);
	}

	@Override
	public void onPause() {
	    super.onPause();
	    uiHelper.onPause();
	}

	@Override
	public void onDestroy() {
	    super.onDestroy();
	    uiHelper.onDestroy();
	}
	
}

class RegisterWithFacebook extends AsyncTask<Void, Void, Integer>
{
	private String name;
	private String lastname;
	private String email;
	private String password;
	private String roominfo;
	private String phone;
	public RegisterWithFacebook(String name,String lastname,String email,String roominfo,String phone)
	{
		this.name=name;
		this.lastname=lastname;
		this.email=email;
		this.password=String.valueOf(email.hashCode());
		this.roominfo=roominfo;
		this.phone=phone;
	}
	@Override
	protected Integer doInBackground(Void... params) {
		Integer o=null;
		o=new ServerRequester().postRegister(this.name,this.lastname,this.email,this.password,this.roominfo,this.phone);
	return o;
	}
	@Override
	protected void onPostExecute(Integer result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
}
	
}

