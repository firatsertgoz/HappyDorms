package edu.sabanciuniv.cs310.happydorms.model;

public class request {

	private int requester_id;
	private int requested_id;
	private boolean type;
	
	
	
}
