package edu.sabanciuniv.cs310.happydorms.model;

public class Ad {

	private int  ad_id;
	private int aduser_id;
	private String roomInfo;
	private String desc;
	private String text;
	private String pic1;
	private String pic2;
	private String pic3;
	private String thumbnail;
	public int getAd_id() {
		return ad_id;
	}
	public void setAd_id(int ad_id) {
		this.ad_id = ad_id;
	}
	public int getAduser_id() {
		return aduser_id;
	}
	public void setAduser_id(int aduser_id) {
		this.aduser_id = aduser_id;
	}
	public String getRoomInfo() {
		return roomInfo;
	}
	public void setRoomInfo(String roomInfo) {
		this.roomInfo = roomInfo;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getPic1() {
		return pic1;
	}
	public void setPic1(String pic1) {
		this.pic1 = pic1;
	}
	public String getPic2() {
		return pic2;
	}
	public void setPic2(String pic2) {
		this.pic2 = pic2;
	}
	public String getPic3() {
		return pic3;
	}
	public void setPic3(String pic3) {
		this.pic3 = pic3;
	}
	public String getThumbnail() {
		return thumbnail;
	}
	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}
	public Ad(int ad_id, int aduser_id, String roomInfo, String desc,
			String text, String pic1, String pic2, String pic3, String thumbnail) {
		super();
		this.ad_id = ad_id;
		this.aduser_id = aduser_id;
		this.roomInfo = roomInfo;
		this.desc = desc;
		this.text = text;
		this.pic1 = pic1;
		this.pic2 = pic2;
		this.pic3 = pic3;
		this.thumbnail = thumbnail;
	}
	
	public Ad(int ad_id, int aduser_id, String roomInfo, String desc,
			String text) {
		super();
		this.ad_id = ad_id;
		this.aduser_id = aduser_id;
		this.roomInfo = roomInfo;
		this.desc = desc;
		this.text = text;
	}
	public Ad(){
		
	}
	
	
	
	
	
}