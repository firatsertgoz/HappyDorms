package edu.sabanciuniv.cs310.happydorms.model;

import java.util.List;

public class user {
	
	private int id;
	private String name;
	private String lastname;
	private String email;
	private String password;
	private String profile_pic;
	private List<String> pictures;
	
	
	

}
