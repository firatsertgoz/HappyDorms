package edu.sabanciuniv.cs310.happydorms;

import java.util.ArrayList;
import java.util.HashMap;

import edu.sabanciuniv.cs310.happydorms.model.Ad;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomPoolListAdapter extends BaseAdapter implements ICallback {

	private ArrayList<Ad> ads;
	private Activity context;
	private HashMap<String,ImageView> requestingImgViews=new HashMap(); 
	
	public CustomPoolListAdapter(Activity context,ArrayList<Ad> ads){
		this.ads=ads;
		this.context=context;	
	}
	public void updateDataSource(ArrayList<Ad> updatedAdList){
		this.ads=updatedAdList;
		//redraw list view
		//very important otherwise your listview won't get updated with change in dataset
		notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		
		return ads.size();
	}

	@Override
	public Object getItem(int position) {
		
		return ads.get(position);
	}

	@Override
	public long getItemId(int position) {
		
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		if(convertView==null){
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.pool_list_layout, parent,false);
		}
		
		TextView title = (TextView) convertView.findViewById(R.id.lvrow_txtTitle);
		TextView desc = (TextView) convertView.findViewById(R.id.lvrow_txtDesc);
		//ImageView thumbnail = ...
		
		Ad ad = ads.get(position);
		title.setText(ad.getRoomInfo()); //roominfo as title
		
		desc.setText(ad.getDesc());
		//img operations...
		
		
		return convertView;
	}

	@Override
	public void callback(Object data) {
		// TODO Auto-generated method stub
		
	}

}
