package edu.sabanciuniv.cs310.happydorms.server;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public class HttpCommunicator {
	
	private HttpClient httpClient;
	
	public HttpCommunicator(){
		
		HttpParams httpParameters = new BasicHttpParams();
		//set timeout in ms, until connection is established
		int connectionTimeout = 10000;
		HttpConnectionParams.setConnectionTimeout(httpParameters, connectionTimeout);
		// Set the default socket timeout in ms, for waiting for data 
		int socketTimeout = 15000;
		HttpConnectionParams.setSoTimeout(httpParameters, socketTimeout);
		httpClient= new DefaultHttpClient(httpParameters);
	}

	public String getJSONString(String URL){
		return get(URL);
	}
	
	private String get(String URL) 
	{
        StringBuilder stringBuilder = new StringBuilder();
        HttpGet httpGet = new HttpGet(URL);
        Log.d("Fetch: ", URL);
        try {
            HttpResponse response = httpClient.execute(httpGet);
            StatusLine statusLine = response.getStatusLine();
            int statusCode = statusLine.getStatusCode();
            //responce is ok
            if (statusCode == 200) 
            {
                InputStream inputStream = response.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                inputStream.close();
            } else {
                Log.e(this.getClass().getName(), "Failed to fetch data: "+URL);
            }
        } catch (Exception e) {
        	Log.e(this.getClass().getName(), e.toString());
        }        
        return stringBuilder.toString();
    }
	
	//ADD code for post request
	
}
