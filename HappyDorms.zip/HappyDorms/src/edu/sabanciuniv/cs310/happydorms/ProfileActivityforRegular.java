package edu.sabanciuniv.cs310.happydorms;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ProfileActivityforRegular extends Activity {
	
	String email=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profileregular_layout);
		
		email=getIntent().getStringExtra("userEmail");
		
		final Button putadButton=(Button)findViewById(R.id.postAd);
		putadButton.setOnClickListener(new OnClickListener() {
			   
			   
			@Override
			public void onClick(View arg0) {
				
				if(putadButton.getText().toString().equals("Cancel Room Ad"))
				{
					putadButton.setText("Post Room Ad");
				}
				else 
					putadButton.setText("Cancel Room Ad");
				
			}
			
		});
		  Button btnAllAds = (Button)findViewById(R.id.allAds);
		    if(btnAllAds == null){
		    	Log.i("DEVELOPER","btn is null");
		    }
		    btnAllAds.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent i = new Intent(ProfileActivityforRegular.this, AddPoolActivity.class);
					startActivity(i);
				}
	});
		    Button logoutButton=(Button) findViewById(R.id.Logout);
		    logoutButton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					new LogoutTask(email,ProfileActivityforRegular.this).execute();
				}
			});
	}
@Override
public void onBackPressed() {
	// TODO Auto-generated method stub
}
class LogoutTask extends AsyncTask<Void, Void, Void>
{
	String email;
	Activity activity;
	public LogoutTask(String email,Activity activity)
	{
	this.email=email;	
	this.activity=activity;
	}
	@Override
	protected Void doInBackground(Void... params) {
		new ServerRequester().Logout(this.email);
		return null;
		// TODO Auto-generated method stub
		
	}
	@Override
	protected void onPostExecute(Void result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
		Intent intent=new Intent(this.activity,LoginActivity.class);
		startActivity(intent);
	}
	
	
}
}
