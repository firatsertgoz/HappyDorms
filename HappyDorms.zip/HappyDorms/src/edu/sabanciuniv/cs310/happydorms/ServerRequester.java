package edu.sabanciuniv.cs310.happydorms;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import edu.sabanciuniv.cs310.happydorms.model.Ad;
import edu.sabanciuniv.cs310.happydorms.server.*;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class ServerRequester {
	
	private HttpCommunicator httpCommunicator;
	
	public ServerRequester(){
			httpCommunicator=new HttpCommunicator();
	}
	public boolean fetchApiKey(int id){
		
		String result=httpCommunicator.getJSONString(AppConstants.getApiKey+id);
		 try {
	            JSONObject jsonObject = new JSONObject(result);
	            Log.d("httpresponce","Resource Fetched:"+jsonObject.toString());
	            
	            if(jsonObject.getInt("serviceMessageCode")==1)
	            {
	            	AppConstants.apikey=jsonObject.getString("serviceMessageText");
	            	return true;
	            }

	        } 
	        catch (Exception e) {
	            Log.e(this.getClass().getName(), e.toString());
	        }        
		return false;
	}

	
//LOGIN USING REGULAR LOGIN.
	//
public boolean Login(String e_mail,String password)
{  
boolean result=false;
try {
	JSONObject returnObject=getJSONObject(AppConstants.login+e_mail+","+password);
	if(returnObject.getString("messageCode").matches("SUCCESS"))
	{
		Log.i("DEVELOPER","SUCCEEDED");
		result=true;
		JSONArray jArr = new JSONArray(returnObject.getString("content"));
		AppConstants.apikey = ((JSONObject)jArr.getJSONObject(0)).getString("apikey");}
	
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
return result;
}
//REGISTER FOR THE APP.
public int postRegister(String name, String lastname, String email,
		String password, String roominfo,String phone){
	int result=1;
	try{
		JSONObject returnObject = getJSONObject(AppConstants.RegisterWithFacebook+email+","+name+","+lastname+","+password);
		if(returnObject.getString("messageCode").equals("SUCCESS")){
			JSONArray jArr = new JSONArray(returnObject.getString("content"));
				AppConstants.apikey = ((JSONObject)jArr.getJSONObject(0)).getString("apikey");
				Log.i("CAPSCAPCAPS",AppConstants.apikey);
				
		}
		else if(returnObject.getString("messageCode").equals("FAILURE"))
		{
			result=2;
		}
	}catch(Exception e){

	}
	return result;
}
//adid,reqid,reqdid,apikey
//MAKE REQUESTS FOR THE ROOM.
public boolean makeRequest(int adid,int reqid,int readid)
{
	if(AppConstants.apikey=="")
		fetchApiKey(reqid);
	boolean result=false;
	try {
		JSONObject returnObject=getJSONObject(AppConstants.postRegister+adid+","+reqid+","+readid);
		if(returnObject.getString("messageCode").matches("SUCCESS"))
		{
			Log.i("DEVELOPER","SUCCEEDED");
			result=true;}
		
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	return result;
}

public JSONObject getJSONObject(String URL){
	String result=httpCommunicator.getJSONString(URL);
	JSONObject jsonObject=null;
	 try {
             jsonObject= new JSONObject(result);
             Log.d("jsonresponce","Resource Fetched:"+jsonObject.toString());
        } 
        catch (Exception e) {
            Log.e(this.getClass().getName(), e.toString());
        }
	 return jsonObject;
}
public ArrayList<Ad> getAllAds(){
	ArrayList ads = new ArrayList<Ad>();
	//TODO get all ads !
	Log.i("CAPSLI",AppConstants.apikey);
	try{
		JSONObject returnObject = getJSONObject(AppConstants.getAllAds+AppConstants.apikey);
		if(returnObject.getString("messageCode").equals("SUCCESS")){
			JSONArray jArr = new JSONArray(returnObject.getString("content"));
			for(int i=0; i<jArr.length();i++){
				int adid = ((JSONObject)jArr.getJSONObject(i)).getInt("Ad_id");
				int id = ((JSONObject)jArr.get(i)).getInt("Aduser_id");
				String roominfo = ((JSONObject)jArr.get(i)).getString("Roominfo");
				String desc = ((JSONObject)jArr.get(i)).getString("Desc");
				String text = ((JSONObject)jArr.get(i)).getString("Text");

				//TODO images.
				ads.add(new Ad(adid,id,roominfo,desc,text));

			}
			new AdsManager().getInstance().setAllAds(ads);
		}
	} catch(Exception e){

	}

	return ads;
}
public void Logout(String email) {
	// TODO Auto-generated method stub
	JSONObject returnObject = getJSONObject(AppConstants.Logout+email);
	try {
		if(returnObject.getString("messageCode").equals("SUCCESS"))
		{
			return;
		}
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	
}



}