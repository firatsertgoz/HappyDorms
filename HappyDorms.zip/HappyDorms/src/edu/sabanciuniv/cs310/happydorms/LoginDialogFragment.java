package edu.sabanciuniv.cs310.happydorms;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import edu.sabanciuniv.cs310.happydorms.ServerRequester;

public class LoginDialogFragment extends DialogFragment {
private ICallback cb;

public void registerCallback(ICallback cb)
{
	this.cb=cb;
}
	@Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        // Add action buttons
       	View dialogView=inflater.inflate(R.layout.login_dialog_layout, null);
        
        final EditText txtEmail=(EditText) dialogView.findViewById(R.id.txtEmail);
        final EditText txtPassword=(EditText) dialogView.findViewById(R.id.txtPassword);
        builder.setView(dialogView)
               .setPositiveButton("Post", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialog, int id) {
                	   if(txtEmail.getText().toString().equals("")|| txtPassword.getText().toString().equals(""))
                	   (Toast.makeText(getActivity().getBaseContext(), "Please fill all fields", Toast.LENGTH_SHORT)).show();
                	   else
                	   {
                		  LoginTask mytask=new LoginTask(cb,(getActivity()),txtEmail.getText().toString(),txtPassword.getText().toString());
                		  mytask.execute();
                	   }
                   }
               })
               .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                       LoginDialogFragment.this.getDialog().cancel();
                   }
               })
               .setTitle("Log in");
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
        alertDialog.getWindow().setLayout(800, 600);
        return alertDialog;
        
    }
	@Override
		public void onAttach(Activity activity) {
			// TODO Auto-generated method stub
			super.onAttach(activity);
			registerCallback((LoginActivity)activity);
		}
}

 class LoginTask extends AsyncTask<Void, Void,Boolean>
{
	 
	 private String e_mail;
	 private String password;
	 private AlertDialog dialog;
	 private Activity activity;
	 private ICallback cb;
	public LoginTask(ICallback cb,Activity activity,String email,String password)
	{
		this.e_mail=email;
		this.password=password;
		this.activity=activity;
		this.cb=cb;
		this.dialog=new ProgressDialog(activity);
		
	}
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
	}
	@Override
	protected Boolean doInBackground(Void...params) {
		Boolean o=null;
		o=new ServerRequester().Login(this.e_mail,this.password);
		return o;
	}
	@Override
	protected void onPostExecute(Boolean result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
		if((Boolean)result==true)
		{
		Intent intent=new Intent(this.activity,ProfileActivityforRegular.class);
		intent.putExtra("userEmail", this.e_mail);
		intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		this.dialog.dismiss();
		activity.startActivity(intent);
		}
		else if((Boolean)result==false)
		{
			Toast.makeText(activity, "Login Failed", Toast.LENGTH_SHORT).show();
	}
	}
}
