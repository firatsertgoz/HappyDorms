package edu.sabanciuniv.cs310.happydorms;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class AdDetailActivity extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ad_detail_layout);
		
		Bundle bundle = getIntent().getExtras();
		
		TextView adDetail = (TextView) findViewById(R.id.txtAdDetail);
		TextView adTitle = (TextView) findViewById(R.id.txtAdTitle);
		adDetail.setText(bundle.getString("Text"));
		adTitle.setText(bundle.getString("Roominfo"));
		
		
	}
	

}
