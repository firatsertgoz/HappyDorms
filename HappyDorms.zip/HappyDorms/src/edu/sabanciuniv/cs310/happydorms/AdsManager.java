package edu.sabanciuniv.cs310.happydorms;

import java.util.ArrayList;

import edu.sabanciuniv.cs310.happydorms.model.Ad;


//singleton
public class AdsManager {
			
		private static AdsManager _instance=null;
		
		private ArrayList<Ad> allAds;
		
		public ArrayList<Ad> getAllAds() {
			return this.allAds;
		}

		public void setAllAds(ArrayList<Ad> allAds) {
			this.allAds = allAds;
		}

			
		AdsManager(){
			allAds=new ArrayList<Ad>();			
		}
		
		public static AdsManager getInstance()
		{
			if(_instance==null)
				_instance=new AdsManager();
			return _instance;
		}

	}