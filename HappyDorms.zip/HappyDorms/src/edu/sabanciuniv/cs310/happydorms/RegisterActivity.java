package edu.sabanciuniv.cs310.happydorms;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.sax.StartElementListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register_layout);
		final EditText name=(EditText) findViewById(R.id.textName);
		final EditText lastname=(EditText) findViewById(R.id.txtLastname);
		final EditText email=(EditText) findViewById(R.id.txtEmail);
		final EditText password=(EditText) findViewById(R.id.txtPassword);
		final EditText repassword=(EditText) findViewById(R.id.txtRePassword);
		final EditText roominfo=(EditText) findViewById(R.id.txtRoominfo);
		final EditText phone=(EditText) findViewById(R.id.txtPhone);
		Button registered=(Button) findViewById(R.id.btn_register);
		Button canceled=(Button) findViewById(R.id.btn_cancel);
		registered.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(name.getText().toString().matches("") || lastname.getText().toString().matches("") || email.getText().toString().matches("")
						|| password.getText().toString().matches("")|| repassword.getText().toString().matches("") 
						|| roominfo.getText().toString().matches("")||phone.getText().toString().matches(""))
             	   (Toast.makeText(getBaseContext(), "Please fill all fields", Toast.LENGTH_SHORT)).show();
				else if(!password.getText().toString().equals(repassword.getText().toString()))
				{
					(Toast.makeText(getBaseContext(), "Passwords do not match", Toast.LENGTH_SHORT)).show();
				}
				else
				{
					RegisterInfo reginfo=new RegisterInfo(RegisterActivity.this,name.getText().toString(),
							lastname.getText().toString(), 
							email.getText().toString(),
							password.getText().toString(),
							 roominfo.getText().toString(),
							 phone.getText().toString());
							reginfo.execute();
				}
			}
		});
		canceled.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(RegisterActivity.this,LoginActivity.class);
				startActivity(intent);
			}
		});
		
	}
	
}
class RegisterInfo extends AsyncTask<Void, Void, Integer>
{
	private String name;
	private String lastname;
	private String email;
	private String password;
	private String roominfo;
	private String phone;
	private Activity activity;
	private ProgressDialog dialog;
	public RegisterInfo(Activity activity,String name,String lastname,String email,String password,String roominfo,String phone)
	{
		this.name=name;
		this.lastname=lastname;
		this.email=email;
		this.password=password;
		this.roominfo=roominfo;
		this.phone=phone;
		this.activity=activity;
		this.dialog=new ProgressDialog(activity);
	}
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
	dialog.setMessage("Registering...");
	dialog.show();
	}

	@Override
	protected Integer doInBackground(Void... params) {
		Integer o=null;
		o=new ServerRequester().postRegister(this.name,this.lastname,this.email,this.password,this.roominfo,this.phone);
		return o;
	}
	@Override
	protected void onPostExecute(Integer result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
		if( (result==0))
		{
		if (dialog.isShowing()) {
			dialog.setMessage("Registration failed.");
			dialog.dismiss();
			}
		}
		if( result==1)
		{
		if (dialog.isShowing()) {
			dialog.setMessage("You have been succesfuly registered.");
            dialog.dismiss();
            Intent intent=new Intent(this.activity,ProfileActivityforRegular.class);
            intent.putExtra("email", this.email);
            activity.startActivity(intent);
			}
		}
		else if(result==2)
		{
				dialog.setMessage("This account has already been registered");
	            dialog.dismiss();
		}
		
	}
	
}
