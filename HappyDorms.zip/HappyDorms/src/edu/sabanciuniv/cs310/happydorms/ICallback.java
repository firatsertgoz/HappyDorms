package edu.sabanciuniv.cs310.happydorms;

public interface ICallback {

	public void callback(Object data);
	
}
