package edu.sabanciuniv.cs310.happydorms;

import java.util.ArrayList;

import edu.sabanciuniv.cs310.happydorms.model.Ad;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;
import android.widget.ListView;

public class AddPoolActivity extends Activity{
	
	
	ArrayList<Ad> ads = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		int reqid=getIntent().getIntExtra("reqid", -1);
		setContentView(R.layout.ad_inpool_layout);
		ProgressDialog dialog = new ProgressDialog(this);
		dialog.setMessage("Fetching ads...");
		
		new getAllAds(this,dialog,reqid).execute();
		
		
		ads = AdsManager.getInstance().getAllAds();
		
		
		
	}
	class getAllAds extends AsyncTask<Void, Void, Void>
	{
		
		private Activity activity;
		private ProgressDialog dialog;
		private CustomPoolListAdapter adapter;
		int reqid;
		public getAllAds(Activity activity,ProgressDialog dialog,int reqid)
		{
			this.reqid=reqid;
			this.activity=activity;
			this.dialog = dialog;
			//dialog.show();
			
			
			
		}
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		
		}

		@Override
		protected Void doInBackground(Void... params) {
			
			new ServerRequester().getAllAds();
			ListView lv = (ListView) activity.findViewById(R.id.listView1);
			this.adapter = new CustomPoolListAdapter(activity,AdsManager.getInstance().getAllAds());
			lv.setAdapter(adapter);
			
			lv.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					Ad currentAd = ((Ad)adapter.getItem(position));
					Intent i = new Intent(activity,AdDetailActivity.class);
					i.putExtra("Ad_id", currentAd.getAd_id());
					i.putExtra("Aduser_id", currentAd.getAduser_id());
					i.putExtra("Roominfo", currentAd.getRoomInfo());
					i.putExtra("Desc", currentAd.getDesc());
					i.putExtra("Text", currentAd.getText());
					i.putExtra("Pic1", currentAd.getPic1());
					i.putExtra("Pic2", currentAd.getPic2());
					i.putExtra("Pic3", currentAd.getPic3());
					i.putExtra("Thumbnail", currentAd.getThumbnail());					
					startActivity(i);
					
				}
			});
			
			return null;
		}
		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			Log.i("developer","inside onPostExecute");
			
				//dialog.setMessage("Done.");
	            //dialog.dismiss();
			
		}
		
	}
}