package edu.sabanciuniv.cs310.happydorms;

public class AppConstants {
	//public static int 
		public static final String serviceBaseUrl="http://192.168.56.1:4444";
		public static String apikey=""; //this will be set by http responce.
		public static String postRegister=serviceBaseUrl+"/register/";
		public static String makeRequest=serviceBaseUrl+"/makerequest/";
		public static String login=serviceBaseUrl+"/login/";
		public static String getAllAds=serviceBaseUrl+"/getallads/";
		public static String getApiKey=serviceBaseUrl+"/getapikey/";
		public static String getUserbyEmail=serviceBaseUrl+"/getuserbyemail/";
		public static String RegisterWithFacebook=serviceBaseUrl+"/registerwithfacebook/";
		public static final String Logout =serviceBaseUrl+"/logout/";
		
		public static final int GET_API_KEY=0;
		public static final int GET_ALL_NEWS=1;
		public static final int GET_ALL_NEWS_CATEGORIES=2;
		public static final int GET_NEWS_BY_ID = 3;
		public static final int GET_COMMENTS_BY_NEWS_ID = 4;
			
	}

