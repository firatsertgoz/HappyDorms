package edu.sabanciuniv.cs310.happydorms;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.sax.StartElementListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateAdActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.create_ad_layout);
		final EditText roominfo=(EditText) findViewById(R.id.roominfo);
		final EditText roomdesc=(EditText) findViewById(R.id.roomdesc);
		final EditText roomtext=(EditText) findViewById(R.id.roomtext);
		Button postad=(Button) findViewById(R.id.btn_postad);
		Button canceled=(Button) findViewById(R.id.btn_cancel);
		postad.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(roominfo.getText().toString().matches(""))
             	   (Toast.makeText(getBaseContext(), "Please fill all fields", Toast.LENGTH_SHORT)).show();
				else
				{
					
							String roominfos=roominfo.getText().toString();
							String roomdescc=roomdesc.getText().toString();
							String roomtextt=roomtext.getText().toString();
							createAdTask createAdTask=new createAdTask(CreateAdActivity.this,roominfos,roomdescc,roomtextt);
									createAdTask.execute();
				}
			}
		});
		canceled.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(CreateAdActivity.this,LoginActivity.class);
				startActivity(intent);
			}
		});
		
	}
	
}
class createAdTask extends AsyncTask<Void, Void, Integer>
{
	private String roominfo;
	private String roomdesc;
	private String roomtext;
	private Activity activity;
	private ProgressDialog dialog;
	public createAdTask(Activity activity,String roominfo,String roomdesc,String roomtext)
	{
		this.roominfo=roominfo;
		this.roomdesc=roomdesc;
		this.roomtext=roomtext;
		this.activity=activity;
		this.dialog=new ProgressDialog(activity);
	}
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
	dialog.setMessage("Registering...");
	dialog.show();
	}

	@Override
	protected Integer doInBackground(Void... params) {
		Integer o=null;
		//o=new ServerRequester().createAd(this.roominfo,this.roomdesc,this.roomtext);
		return o;
	}
	@Override
	protected void onPostExecute(Integer result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
		if( (result==0))
		{
		if (dialog.isShowing()) {
			dialog.setMessage("Registration failed.");
			dialog.dismiss();
			}
		}
		if( result==1)
		{
		if (dialog.isShowing()) {
			dialog.setMessage("You have been succesfuly registered.");
            dialog.dismiss();
            Intent intent=new Intent(this.activity,ProfileActivityforRegular.class);
            activity.startActivity(intent);
			}
		}
		else if(result==2)
		{
				dialog.setMessage("This account has already been registered");
	            dialog.dismiss();
		}
		
	}
	
}
