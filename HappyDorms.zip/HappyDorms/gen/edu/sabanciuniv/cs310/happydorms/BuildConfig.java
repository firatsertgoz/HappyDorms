/** Automatically generated file. DO NOT MODIFY */
package edu.sabanciuniv.cs310.happydorms;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}